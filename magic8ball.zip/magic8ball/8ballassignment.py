import flet as ft
import random

def main(page: ft.Page):

    page.title = "Magic 8 Ball"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    responses = [
        "images/idkanswer.jpg",
        "images/askagain.png",
        "images/maybeanswer.png",
        "images/yesanswer.png",
        "images/noanswer.png",
    ]

    ball = ft.Image(src="images/8ball.jpg", height=350, width=350)
    question = ft.TextField(label="Ask a yes/no question", width=400)

    def answer(e):
        if question.value == "":
            return
        magic_chance = random.randint(0, len(responses) - 1)
        ball.src = responses[magic_chance]
        page.update()

    button = ft.ElevatedButton(content="Ask the 8-Ball", on_click=answer)

    page.add(question, button, ball)

ft.app(target=main, assets_dir="assets")
